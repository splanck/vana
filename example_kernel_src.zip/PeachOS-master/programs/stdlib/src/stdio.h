#ifndef PEACHOS_STDIO
#define PEACHOS_STDIO

int putchar(int c);
int printf(const char *fmt, ...);

#endif